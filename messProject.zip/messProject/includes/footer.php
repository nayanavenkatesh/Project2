<footer class="footer text-center text-muted">
&copy; <?php echo date("Y"); ?> - Mess Management System  
</footer>
