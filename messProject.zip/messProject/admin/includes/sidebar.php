<!-- Sidebar navigation-->
<nav class="sidebar-nav">

    <ul id="sidebarnav">
    
       

        <li class="list-divider"></li>

        <li class="nav-small-cap"><span class="hide-menu">Features</span></li>
                            
      

        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="view-students-acc.php"
        aria-expanded="false"><i class="fas fa-user-circle"></i><span
        class="hide-menu">View Students </span></a></li>

  <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="attendance.php"
        aria-expanded="false"><i class="fas fa-h-square"></i><span
        class="hide-menu">Attendance</span></a></li>
        
         <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="view_bill.php"
        aria-expanded="false"><i class="fas fa-user-circle"></i><span
        class="hide-menu">View Bill </span></a></li>
        
        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="bookings.php"
        aria-expanded="false"><i class="fas fa-h-square"></i><span
        class="hide-menu">Student Registration</span></a></li>
        
  <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="add-rooms.php"
        aria-expanded="false"><i class="fas fa-h-square"></i><span
        class="hide-menu">Add Room</span></a></li>
        
         <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="add-bill.php"
        aria-expanded="false"><i class="fas fa-h-square"></i><span
        class="hide-menu">Mess Bill</span></a></li>
        
        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="view-feedback.php"
        aria-expanded="false"><i class="fas fa-h-square"></i><span
        class="hide-menu">View Feedback</span></a></li>
      
        
        


     
                           
    </ul>
</nav>
<!-- End Sidebar navigation -->
